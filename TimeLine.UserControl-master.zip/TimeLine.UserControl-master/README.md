# TimeLine.UserControl
Timeline/Gantt User Control in C# 

An old Windows desktop project that displays a Gantt Chart as a windows form user control.
