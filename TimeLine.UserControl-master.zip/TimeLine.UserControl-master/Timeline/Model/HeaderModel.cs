﻿using System;

namespace Timeline.Model
{
    public class HeaderModel
    {
        public int StartLocation { get; set; }
        public DateTime HeaderDateTime { get; set; }
    }
}
